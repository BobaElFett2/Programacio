public class Ejercicio1 {

    public static void main(String[] args) {

        for (int i = 1; i < 21; i++) {
            System.out.println(i);
        }

    }
}
