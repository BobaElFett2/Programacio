public class Ejercicio2 {

   public  static void main (String [] args) {

       int suma = 0;

       for (int i = 0; i <= 99; i++) {

               suma = suma + 2;
               System.out.println(suma);
       }

       System.out.println(suma);

   }

}
