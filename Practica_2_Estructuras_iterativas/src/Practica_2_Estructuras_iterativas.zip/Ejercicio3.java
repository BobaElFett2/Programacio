public class Ejercicio3 {

    public  static void main (String [] args) {

        // int suma = 0;

        for (int i = 0; i < 201; i = i + 2) {
             // if (i % 2 == 0) {
             //   System.out.println(i);
             //   suma = suma + 1 + 1;
             // }

            System.out.println(i);

        }


    }
}
